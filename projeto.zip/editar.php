<?php
// Ligação ao Azure SQL
require_once 'db.php';

// Validar ID
if (!isset($_GET['id'])) {
    die("ID não fornecido.");
}

$id = (int) $_GET['id'];

// Buscar registo
try {
    $stmt = $conn->prepare("SELECT * FROM faturas WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $fatura = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$fatura) {
        die("Fatura não encontrada.");
    }

} catch (Exception $e) {
    die("Erro ao obter fatura: " . $e->getMessage());
}

// Guardar alterações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $titulo        = $_POST['titulo'];
    $data          = $_POST['data'];
    $valor_sem_iva = $_POST['valor_sem_iva'];
    $valor_com_iva = $_POST['valor_com_iva'];

    try {
        $sql = "UPDATE faturas SET titulo = :t, data = :d, valor_sem_iva = :vs, valor_com_iva = :vc WHERE id = :id";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':t' => $titulo,
            ':d' => $data,
            ':vs' => $valor_sem_iva,
            ':vc' => $valor_com_iva,
            ':id' => $id
        ]);

        header("Location: listar.php");
        exit;

    } catch (Exception $e) {
        die("Erro ao atualizar: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <title>Editar Fatura</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Editar Fatura</h1>

<form method="POST" class="form-container">
    <label for="titulo">Título:</label>
    <input type="text" id="titulo" name="titulo" value="<?= htmlspecialchars($fatura['titulo']) ?>" required>

    <label for="data">Data:</label>
    <input type="date" id="data" name="data" value="<?= htmlspecialchars($fatura['data']) ?>" required>

    <label for="valor_sem_iva">Valor sem IVA:</label>
    <input type="number" step="0.01" id="valor_sem_iva" name="valor_sem_iva" value="<?= htmlspecialchars($fatura['valor_sem_iva']) ?>" required>

    <label for="valor_com_iva">Valor com IVA:</label>
    <input type="number" step="0.01" id="valor_com_iva" name="valor_com_iva" value="<?= htmlspecialchars($fatura['valor_com_iva']) ?>" required>

    <button type="submit">Guardar Alterações</button>
</form>

<br>
<a href="listar.php" class="list-link">Voltar à lista</a>

</body>
</html>
