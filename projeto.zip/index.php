<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Faturas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Gestão de Faturas</h1>

<div class="menu-container">
    <a class="menu-btn" href="insert.php">Inserir Nova Fatura</a>
    <a class="menu-btn" href="listar.php">Listar Faturas</a>
</div>

</body>
</html>
