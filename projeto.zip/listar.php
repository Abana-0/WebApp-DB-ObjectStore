<?php
// Ligação ao Azure SQL
require_once 'db.php';

// Buscar todos os registos
try {
    $stmt = $conn->query("SELECT * FROM faturas ORDER BY id DESC");
    $faturas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Erro ao obter dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <title>Lista de Faturas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Faturas Inseridas</h1>

<table class="tabela" border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Data</th>
        <th>Valor s/ IVA</th>
        <th>Valor c/ IVA</th>
        <th>Documento</th>
        <th>Ações</th>
    </tr>

    <?php if (empty($faturas)): ?>
        <tr><td colspan="7" style="text-align:center">Sem registos.</td></tr>
    <?php else: ?>
        <?php foreach ($faturas as $f): ?>
            <tr>
                <td><?= htmlspecialchars($f['id']) ?></td>
                <td><?= htmlspecialchars($f['titulo']) ?></td>
                <td><?= htmlspecialchars($f['data']) ?></td>
                <td><?= htmlspecialchars($f['valor_sem_iva']) ?></td>
                <td><?= htmlspecialchars($f['valor_com_iva']) ?></td>
                <td>
                    <?php if (!empty($f['ficheiro_url'])): ?>
                        <a href="<?= htmlspecialchars($f['ficheiro_url']) ?>" target="_blank">Abrir</a>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
                <td>
                    <a href="editar.php?id=<?= urlencode($f['id']) ?>">Editar</a> |
                    <a href="eliminar.php?id=<?= urlencode($f['id']) ?>" onclick="return confirm('Eliminar esta fatura?');">Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
</table>

<br>
<a href="index.php" class="list-link">Voltar ao início</a>

</body>
</html>
