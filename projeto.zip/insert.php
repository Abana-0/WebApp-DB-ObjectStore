<?php

require_once 'db.php';
require 'vendor/autoload.php';

use MicrosoftAzure\Storage\Blob\BlobRestProxy;

// Se o formulário foi submetido, processa os dados
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Dados do formulário
    $titulo        = $_POST['titulo'] ?? null;
    $data          = $_POST['data'] ?? null;
    $valor_sem_iva = $_POST['valor_sem_iva'] ?? null;
    $valor_com_iva = $_POST['valor_com_iva'] ?? null;

    if (!$titulo || !$data || !$valor_sem_iva || !$valor_com_iva) {
        die("Dados incompletos.");
    }

    // Valor por defeito caso não haja ficheiro
    $ficheiro_url = null;

    // --- UPLOAD SIMPLES DE PDF PARA AZURE BLOB STORAGE ---
    if (!empty($_FILES['documento']['name']) && $_FILES['documento']['error'] === UPLOAD_ERR_OK) {

    // Ligar ao Blob Storage
    $blobClient = BlobRestProxy::createBlobService(getenv('BLOB_CONN'));
    $container  = getenv('BLOB_CONTAINER');

    $tmpPath  = $_FILES['documento']['tmp_name'];

    // Nome totalmente seguro
    $blobName = time() . "_anexo.pdf";

    try {
        $fileHandle = fopen($tmpPath, 'r');
        $blobClient->createBlockBlob($container, $blobName, $fileHandle);

        // URL do ficheiro no Azure Blob
        $ficheiro_url = "https://" . getenv('AZURE_STORAGE_ACCOUNT') .
                        ".blob.core.windows.net/$container/$blobName";

    } catch (Exception $e) {
        die("Erro ao enviar PDF: " . $e->getMessage());
    }
    }


    // Inserir na base de dados
    try {
        $sql = "INSERT INTO faturas (titulo, data, valor_sem_iva, valor_com_iva, ficheiro_url)
                VALUES (:t, :d, :vs, :vc, :f)";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':t' => $titulo,
            ':d' => $data,
            ':vs' => $valor_sem_iva,
            ':vc' => $valor_com_iva,
            ':f' => $ficheiro_url
        ]);

        header("Location: listar.php");
        exit;

    } catch (Exception $e) {
        die("Erro ao inserir na BD: " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Inserir Nova Fatura</title>
</head>
<body>

<h1>Inserir Nova Fatura</h1>

<!-- FORMULARIO COM UPLOAD DE PDF -->
<form method="POST" enctype="multipart/form-data">

    <label>Título:</label><br>
    <input type="text" name="titulo" required><br><br>

    <label>Data:</label><br>
    <input type="date" name="data" required><br><br>

    <label>Valor sem IVA:</label><br>
    <input type="number" step="0.01" name="valor_sem_iva" required><br><br>

    <label>Valor com IVA:</label><br>
    <input type="number" step="0.01" name="valor_com_iva" required><br><br>

    <label>Anexo (PDF opcional):</label><br>
    <input type="file" name="documento" accept="application/pdf"><br><br>

    <button type="submit">Inserir Fatura</button>

</form>

<br><br>
<a href="index.php">Voltar ao Menu</a>

</body>
</html>
