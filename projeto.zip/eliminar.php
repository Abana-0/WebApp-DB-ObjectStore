<?php
// IMPORTAÇÕES DEVEM ESTAR NO TOPO
require_once 'db.php';
require 'vendor/autoload.php';

use MicrosoftAzure\Storage\Blob\BlobRestProxy;

// Validar ID
if (!isset($_GET['id'])) {
    die("ID não fornecido.");
}

$id = (int) $_GET['id'];

// Buscar URL do ficheiro (para eliminar do Blob)
try {
    $stmt = $conn->prepare("SELECT ficheiro_url FROM faturas WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $fatura = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$fatura) {
        die("Fatura não encontrada.");
    }

} catch (Exception $e) {
    die("Erro ao buscar fatura: " . $e->getMessage());
}

// Eliminar registo da BD
try {
    $stmt = $conn->prepare("DELETE FROM faturas WHERE id = :id");
    $stmt->execute([':id' => $id]);

} catch (Exception $e) {
    die("Erro ao eliminar registo: " . $e->getMessage());
}

// Eliminar ficheiro do Azure Blob Storage (se existir)
if (!empty($fatura['ficheiro_url'])) {

    $blobClient = BlobRestProxy::createBlobService(getenv('BLOB_CONN'));
    $container  = getenv('BLOB_CONTAINER');

    // Extrair nome do blob da URL
    $parts = explode('/', $fatura['ficheiro_url']);
    $blobName = end($parts);

    try {
        $blobClient->deleteBlob($container, $blobName);

    } catch (Exception $e) {
        // Não parar a app
        // echo "Aviso: não foi possível eliminar o ficheiro do Blob: " . $e->getMessage();
    }
}

// Redirecionar para a lista
header("Location: listar.php");
exit;
